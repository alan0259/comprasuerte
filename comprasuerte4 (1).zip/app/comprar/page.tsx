"use client"

import type React from "react"
import { useState, useEffect, useCallback, useRef } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import Header from "../components/Header"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { sanitizeInput, validateInput } from "@/utils/security"

export default function Comprar() {
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null)
  const [selectedTicket, setSelectedTicket] = useState<number | null>(null)
  const [soldTickets, setSoldTickets] = useState<number[]>([])
  const [currentPage, setCurrentPage] = useState(0)
  const [formData, setFormData] = useState({
    Nombre: "",
    Apellidos: "",
    Carnet: "",
    Direccion: "",
    Telefono: "",
  })
  const [formErrors, setFormErrors] = useState({
    Nombre: "",
    Apellidos: "",
    Carnet: "",
    Direccion: "",
    Telefono: "",
  })
  const [isConnected, setIsConnected] = useState(false)
  const [connectionError, setConnectionError] = useState<string | null>(null)

  const eventSourceRef = useRef<EventSource | null>(null)
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const products = [
    {
      id: 1,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-02-20%20a%20las%2020.53.50_6ab597b2-Photoroom-LGUgzB7DD0X5PEzGLxEYioOJIEYGhl.png",
      name: "Bicicleta bucatti",
      details: "1000W / 48V / 22.5Ah, autonomía de más de 60 km",
    },
    {
      id: 2,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pixelcut-export-kj1R48QXENEBIo8whS8IvbsNxNAbJF.png",
      name: "Lavadora secadora LG",
      details: "Lavadora secadora LG de 14 kg",
    },
    {
      id: 3,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-02-20%20a%20las%2019.24.06_07b3fa68-Photoroom-8VTa8OvyMLBELkFQOODnpJk7EYVQZF.png",
      name: "planta electrica pulsar ",
      details: "Planta eléctrica pulsar inverter ultra silenciosa motor de 4 tiempos",
    },
  ]

  const totalPages = 10
  const [showDetails, setShowDetails] = useState<number | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const getCurrentPageTickets = useCallback((currentPage: number) => {
    const start = currentPage * 100 + 1
    return Array.from({ length: 100 }, (_, i) => start + i)
  }, [])

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  const connectSSE = useCallback(() => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close()
    }

    const eventSource = new EventSource("/api/sse")
    eventSourceRef.current = eventSource

    eventSource.onopen = () => {
      console.log("Conexión SSE establecida")
      setIsConnected(true)
      setConnectionError(null)
    }

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        if (data.soldTickets) {
          setSoldTickets(data.soldTickets)
        }
      } catch (error) {
        console.error("Error al procesar los datos:", error)
      }
    }

    eventSource.onerror = (error) => {
      console.error("Error en la conexión SSE:", error)
      setIsConnected(false)
      setConnectionError("Error de conexión. Reintentando...")
      eventSource.close()

      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current)
      }

      retryTimeoutRef.current = setTimeout(() => {
        connectSSE()
      }, 5000)
    }

    return () => {
      eventSource.close()
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current)
      }
    }
  }, [])

  useEffect(() => {
    const cleanup = connectSSE()
    return cleanup
  }, [connectSSE])

  const handleProductSelect = (productId: number) => {
    setSelectedProduct(productId)
    setSelectedTicket(null)
    setCurrentPage(0)
  }

  const handleTicketSelect = (ticketNumber: number) => {
    if (!soldTickets.includes(ticketNumber)) {
      setSelectedTicket(ticketNumber)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    const sanitizedValue = sanitizeInput(value)
    setFormData((prev) => ({ ...prev, [name]: sanitizedValue }))

    let isValid = false
    let errorMessage = ""

    switch (name) {
      case "Nombre":
      case "Apellidos":
        isValid = validateInput(sanitizedValue, "name")
        errorMessage = isValid ? "" : "Debe contener solo letras y espacios (2-50 caracteres)"
        break
      case "Carnet":
        isValid = validateInput(sanitizedValue, "id")
        errorMessage = isValid ? "" : "Debe contener exactamente 11 dígitos"
        break
      case "Direccion":
        isValid = validateInput(sanitizedValue, "address")
        errorMessage = isValid ? "" : "Debe tener entre 5 y 100 caracteres"
        break
      case "Telefono":
        isValid = validateInput(sanitizedValue, "phone")
        errorMessage = isValid ? "" : "Debe ser un número de teléfono válido"
        break
    }

    setFormErrors((prev) => ({ ...prev, [name]: errorMessage }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedTicket !== null && Object.values(formErrors).every((error) => error === "")) {
      try {
        const response = await fetch("/api/sse", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ ticketNumber: selectedTicket }),
        })

        const data = await response.json()

        if (data.success) {
          const whatsappMessage = encodeURIComponent(
            `Hola, quiero comprar el boleto número ${selectedTicket} para ${
              products.find((p) => p.id === selectedProduct)?.name
            }. Mis datos son: ${JSON.stringify(formData)}`,
          )
          window.open(`https://wa.me/+5358038628?text=${whatsappMessage}`, "_blank")

          // Reiniciar el formulario
          setSelectedTicket(null)
          setFormData({
            Nombre: "",
            Apellidos: "",
            Carnet: "",
            Direccion: "",
            Telefono: "",
          })
          setFormErrors({
            Nombre: "",
            Apellidos: "",
            Carnet: "",
            Direccion: "",
            Telefono: "",
          })
        } else {
          alert("Este boleto ya no está disponible. Por favor, seleccione otro.")
        }
      } catch (error) {
        console.error("Error al comprar el boleto:", error)
        alert("Hubo un error al procesar su compra. Por favor, intente de nuevo.")
      }
    }
  }

  return (
    <div className="min-h-screen bg-[#1a1a1a] text-[#f5f5f5]">
      <Header />
      <main className="container mx-auto mt-4 sm:mt-8 px-2 sm:px-4">
        <h1 className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-8 text-center">Selecciona tu Premio</h1>

        {connectionError && <div className="bg-red-500 text-white p-2 mb-4 rounded">{connectionError}</div>}

        {!isConnected && !connectionError && (
          <div className="bg-yellow-500 text-black p-2 mb-4 rounded">Conectando al servidor...</div>
        )}

        {!selectedProduct ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-8 mb-8">
            {products.map((product) => (
              <div key={product.id} className="flex flex-col items-center">
                <div className="relative w-full aspect-square mb-4">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-contain"
                    loading="lazy"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                </div>
                <Button
                  onClick={() => handleProductSelect(product.id)}
                  className="w-full max-w-xs bg-[#f5f5f5] text-[#1a1a1a] hover:bg-gray-300 mb-2"
                >
                  Seleccionar {product.name}
                </Button>
                <Button
                  onClick={() => setShowDetails(showDetails === product.id ? null : product.id)}
                  className="w-full max-w-xs bg-gray-700 text-[#f5f5f5] hover:bg-gray-600"
                >
                  {showDetails === product.id ? "Ocultar Detalles" : "Mostrar Detalles"}
                </Button>
                {showDetails === product.id && <p className="mt-2 text-sm text-center">{product.details}</p>}
              </div>
            ))}
          </div>
        ) : (
          <>
            <Button onClick={() => setSelectedProduct(null)} className="mb-4 sm:mb-8 bg-gray-700 hover:bg-gray-600">
              ← Volver a Premios
            </Button>

            <div className="relative">
              <div className="absolute left-0 top-1/2 -translate-y-1/2 z-10">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setCurrentPage((prev) => Math.max(0, prev - 1))}
                  disabled={currentPage === 0}
                  className="w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              </div>

              <div className="absolute right-0 top-1/2 -translate-y-1/2 z-10">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setCurrentPage((prev) => Math.min(totalPages - 1, prev + 1))}
                  disabled={currentPage === totalPages - 1}
                  className="w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              {!isLoading ? (
                <div className="overflow-hidden px-2 sm:px-8">
                  <div className="grid grid-cols-5 sm:grid-cols-10 gap-1 sm:gap-2 mb-4">
                    {getCurrentPageTickets(currentPage).map((number) => (
                      <button
                        key={number}
                        onClick={() => handleTicketSelect(number)}
                        className={`aspect-square flex items-center justify-center text-xs sm:text-sm rounded ${
                          soldTickets.includes(number)
                            ? "bg-black text-gray-600 cursor-not-allowed"
                            : selectedTicket === number
                              ? "bg-gray-600"
                              : "bg-[#f5f5f5] text-[#1a1a1a] hover:bg-gray-300"
                        }`}
                        disabled={soldTickets.includes(number)}
                      >
                        {number}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex justify-center items-center h-40">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#f5f5f5]"></div>
                </div>
              )}

              <div className="flex justify-center gap-2 mt-4">
                {Array.from({ length: totalPages }).map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentPage(index)}
                    className={`w-2 h-2 rounded-full ${currentPage === index ? "bg-[#f5f5f5]" : "bg-gray-600"}`}
                  />
                ))}
              </div>
            </div>

            {selectedTicket && (
              <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4 mt-8">
                <div>
                  <input
                    type="text"
                    name="Nombre"
                    placeholder="Nombre"
                    value={formData.Nombre}
                    onChange={handleInputChange}
                    className="w-full p-2 rounded bg-gray-800 text-white"
                    required
                  />
                  {formErrors.Nombre && <p className="text-red-500 text-sm mt-1">{formErrors.Nombre}</p>}
                </div>
                <div>
                  <input
                    type="text"
                    name="Apellidos"
                    placeholder="Apellidos"
                    value={formData.Apellidos}
                    onChange={handleInputChange}
                    className="w-full p-2 rounded bg-gray-800 text-white"
                    required
                  />
                  {formErrors.Apellidos && <p className="text-red-500 text-sm mt-1">{formErrors.Apellidos}</p>}
                </div>
                <div>
                  <input
                    type="text"
                    name="Carnet"
                    placeholder="Carnet de Identidad"
                    value={formData.Carnet}
                    onChange={handleInputChange}
                    className="w-full p-2 rounded bg-gray-800 text-white"
                    required
                  />
                  {formErrors.Carnet && <p className="text-red-500 text-sm mt-1">{formErrors.Carnet}</p>}
                </div>
                <div>
                  <input
                    type="text"
                    name="Direccion"
                    placeholder="Dirección"
                    value={formData.Direccion}
                    onChange={handleInputChange}
                    className="w-full p-2 rounded bg-gray-800 text-white"
                    required
                  />
                  {formErrors.Direccion && <p className="text-red-500 text-sm mt-1">{formErrors.Direccion}</p>}
                </div>
                <div>
                  <input
                    type="tel"
                    name="Telefono"
                    placeholder="Teléfono"
                    value={formData.Telefono}
                    onChange={handleInputChange}
                    className="w-full p-2 rounded bg-gray-800 text-white"
                    required
                  />
                  {formErrors.Telefono && <p className="text-red-500 text-sm mt-1">{formErrors.Telefono}</p>}
                </div>
                <p className="text-base font-medium text-[#f5f5f5] mt-4 mb-2 text-center">
                  Bonificación: la persona que comparta el enlace con el ganador recibirá una bonificación de 100 USD
                </p>
                <Button
                  type="submit"
                  className="w-full bg-[#f5f5f5] text-[#1a1a1a] hover:bg-gray-300 mt-4"
                  disabled={
                    Object.values(formErrors).some((error) => error !== "") || soldTickets.includes(selectedTicket)
                  }
                >
                  Comprar Boleto #{selectedTicket}
                </Button>
              </form>
            )}
          </>
        )}
      </main>
    </div>
  )
}

