import Header from "./components/Header"
import Link from "next/link"

export default function Home() {
  return (
    <div className="min-h-screen bg-[#1a1a1a] text-[#f5f5f5]">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <section className="text-center mb-16">
          <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold mb-8 leading-tight">
            Bienvenido a Comprasuerte
          </h1>
        </section>

        {/* Call to Action */}
        <section className="text-center mb-8">
          <p className="text-xl sm:text-2xl font-semibold text-[#f5f5f5] mb-4">Precio: 1000 CUP</p>
          <Link
            href="/comprar"
            className="inline-block bg-[#f5f5f5] text-[#1a1a1a] px-8 sm:px-12 py-4 sm:py-6 rounded-full text-xl sm:text-2xl font-bold hover:bg-gray-300 transition-all duration-300 transform hover:scale-105 shadow-lg mb-4"
          >
            Comprar Boletos
          </Link>
          <p className="text-lg sm:text-xl text-[#f5f5f5] font-semibold mt-4">
            ¡La persona que compre el boleto ganador recibirá además 100 USD!
          </p>
        </section>

        {/* Security Disclaimer */}
        <footer className="text-center mt-16">
          <p className="text-xs text-gray-400 mb-2">
            Aviso de Seguridad: Este sitio web implementa medidas de seguridad estándar. Por favor, use con precaución.
          </p>
          <p className="text-xs text-gray-500">
            Aviso: Si no se llega a completar la venta de los boletos, se le reembolsará el 100% del costo del boleto.
          </p>
        </footer>
      </main>
    </div>
  )
}

